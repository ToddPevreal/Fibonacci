﻿using System.Collections.Generic;

namespace Web.Services
{
    public class FibonacciService : IFibonacciService
    {
        public IEnumerable<int> GenerateFibonacciSequence(int numbersToGenerate)
        {
            
            int a = 0;
            int b = 1;

            // In N steps compute Fibonacci sequence iteratively.
            for (int i = 0; i < numbersToGenerate; i++)
            {
                int temp = a;
                a = b;
                b = temp + b;
                yield return a;
            }
        }
    }
}